package com.example.spring4.common;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MapVO {
    private double lat;
    private double lng;
}
